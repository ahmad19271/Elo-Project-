import axios from "axios";

class OrderAPI {
  createOrder = async (order) => {
    try {
      const token = JSON.parse(localStorage.getItem("userInfo")).token;

      const config = {
        headers: {
          "Content-type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      };

      const { data } = await axios.post(`/api/orders/add/`, order, config);

      // Add console log for demonstration purposes
      console.log("Order created:", data);

      return data;
    } catch (error) {
      throw error.response && error.response.data.detail
        ? error.response.data.detail
        : error.message;
    }
  };

  // Other order-related methods...

}

const orderAPI = new OrderAPI();

export default orderAPI;
