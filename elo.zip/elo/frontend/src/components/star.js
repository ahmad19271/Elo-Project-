import React from "react";
import { makeStyles } from "@material-ui/core/styles";
import StarIcon from "@material-ui/icons/Star";

const useStyles = makeStyles(() => ({
  container: {
    display: "flex",
    justifyContent: "center",
    alignItems: "center",
    margin: "20px", // Adjust margin as needed
  },
  star: {
    color: "#FFD700", // Set star color
  },
}));

const Star = ({ rating }) => {
  const classes = useStyles();

  const renderStars = () => {
    const stars = [];
    for (let i = 0; i < 5; i++) {
      stars.push(
        <StarIcon key={i} className={classes.star} fontSize="small" />
      );
    }
    return stars;
  };

  return (
    <div className={classes.container}>
      {renderStars()}
      <p>Rating: {rating}</p>
    </div>
  );
};

export default Star;
