import React from "react";
import CircularProgress from "@material-ui/core/CircularProgress";
import Typography from "@material-ui/core/Typography";
import { makeStyles } from "@material-ui/core/styles";

const useStyles = makeStyles((theme) => ({
  loaderContainer: {
    display: "flex",
    flexDirection: "column",
    alignItems: "center",
    justifyContent: "center",
    height: "100vh", // Adjust the height as needed
  },
  loader: {
    marginBottom: theme.spacing(2), // Add some space below the loader
  },
  loaderText: {
    color: theme.palette.primary.main, // Change the text color
  },
}));

export default function Loader() {
  const classes = useStyles();

  return (
    <div className={classes.loaderContainer}>
      <CircularProgress className={classes.loader} size={100} color="secondary" />
      <Typography variant="h6" className={classes.loaderText}>
        Loading...
      </Typography>
    </div>
  );
}
