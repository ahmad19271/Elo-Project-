import React from "react";
import { Link } from "react-router-dom";
import { Breadcrumbs, Typography } from "@material-ui/core";
import { makeStyles } from "@material-ui/core/styles";

const useStyles = makeStyles((theme) => ({
  link: {
    display: "flex",
    color: theme.palette.primary.main,  // Change the default color to the primary color
    textDecoration: "none",
    fontWeight: "bold",  // Add bold font weight for all links
    marginRight: theme.spacing(2),  // Add some spacing between links
  },
  activeLink: {
    color: theme.palette.secondary.main,  // Change the active link color to the secondary color
  },
}));

function CheckoutSteps({ step1, step2, step3 }) {
  const classes = useStyles();

  return (
    <Breadcrumbs aria-label="breadcrumb">
      <Link
        to="/login"
        className={`${classes.link} ${step1 ? classes.activeLink : ""}`}
      >
        {step1 ? "Sign In" : "Sign In (Incomplete)"}
      </Link>

      <Link
        to="/shipping"
        className={`${classes.link} ${step2 ? classes.activeLink : ""}`}
      >
        {step2 ? "Shipping Details" : "Shipping Details (Incomplete)"}
      </Link>

      <Typography
        color={step3 ? "textPrimary" : "textSecondary"}
        className={`${classes.link} ${step3 ? classes.activeLink : ""}`}
      >
        {step3 ? "Review and Confirm Order" : "Review and Confirm Order (Incomplete)"}
      </Typography>
    </Breadcrumbs>
  );
}

export default CheckoutSteps;
