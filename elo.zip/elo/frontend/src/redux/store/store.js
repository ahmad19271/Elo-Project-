import { useDispatch as useReduxDispatch, useSelector as useReduxSelector } from 'react-redux';
import { configureStore, applyMiddleware } from '@reduxjs/toolkit';
import thunk from 'redux-thunk';
import { rootReducer } from './rootReducer';

// Configure the Redux store with rootReducer and middleware
const store = configureStore({
  reducer: rootReducer,
  devTools: process.env.REACT_APP_ENABLE_REDUX_DEV_TOOLS === 'true',
  middleware: [thunk], // Add middleware if needed
});

// Export customized useDispatch and useSelector hooks
export const useSelector = useReduxSelector;
export const useDispatch = () => useReduxDispatch();

export default store;
